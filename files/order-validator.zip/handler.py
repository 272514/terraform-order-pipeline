def lambda_handler(event, context):
    print("Wywolano funkcje: order-validator")
    return {
        "statusCode": 200, 
        "body": "Hello from stable order-validator built by Terraform!"
    }
