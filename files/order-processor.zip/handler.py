def lambda_handler(event, context):
    print("Wywolano funkcje: order-processor")
    return {
        "statusCode": 200, 
        "body": "Hello from stable order-processor built by Terraform!"
    }
