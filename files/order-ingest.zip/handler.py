def lambda_handler(event, context):
    print("Wywolano funkcje: order-ingest")
    return {
        "statusCode": 200, 
        "body": "Hello from stable order-ingest built by Terraform!"
    }
